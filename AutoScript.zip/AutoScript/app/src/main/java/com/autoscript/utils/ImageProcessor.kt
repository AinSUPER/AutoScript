package com.autoscript.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import com.autoscript.service.AccessibilityServiceImpl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImageProcessor(private val context: Context) {

    private var isInitialized = true

    fun isInitialized(): Boolean = isInitialized

    suspend fun findImage(
        sourceBitmap: Bitmap,
        templateBitmap: Bitmap,
        similarity: Double = 0.9
    ): Rect? = withContext(Dispatchers.Default) {
        val result = findTemplateMatch(sourceBitmap, templateBitmap, similarity)
        result
    }

    private fun findTemplateMatch(
        source: Bitmap,
        template: Bitmap,
        threshold: Double
    ): Rect? {
        val sourceWidth = source.width
        val sourceHeight = source.height
        val templateWidth = template.width
        val templateHeight = template.height

        if (templateWidth > sourceWidth || templateHeight > sourceHeight) {
            return null
        }

        val sourcePixels = IntArray(sourceWidth * sourceHeight)
        val templatePixels = IntArray(templateWidth * templateHeight)
        source.getPixels(sourcePixels, 0, sourceWidth, 0, 0, sourceWidth, sourceHeight)
        template.getPixels(templatePixels, 0, templateWidth, 0, 0, templateWidth, templateHeight)

        var bestMatch: Rect? = null
        var bestScore = 0.0

        val stepX = (templateWidth / 4).coerceAtLeast(1)
        val stepY = (templateHeight / 4).coerceAtLeast(1)

        for (y in 0..(sourceHeight - templateHeight) step stepY) {
            for (x in 0..(sourceWidth - templateWidth) step stepX) {
                val score = calculateSimilarity(
                    sourcePixels, sourceWidth, x, y,
                    templatePixels, templateWidth, templateHeight
                )
                if (score > bestScore && score >= threshold) {
                    bestScore = score
                    bestMatch = Rect(x, y, x + templateWidth, y + templateHeight)
                }
            }
        }

        return bestMatch
    }

    private fun calculateSimilarity(
        source: IntArray, sourceWidth: Int, startX: Int, startY: Int,
        template: IntArray, templateWidth: Int, templateHeight: Int
    ): Double {
        var sumDiff = 0.0
        val totalPixels = templateWidth * templateHeight

        for (ty in 0 until templateHeight) {
            for (tx in 0 until templateWidth) {
                val sourceIdx = (startY + ty) * sourceWidth + (startX + tx)
                val templateIdx = ty * templateWidth + tx

                val sPixel = source[sourceIdx]
                val tPixel = template[templateIdx]

                val sR = (sPixel shr 16) and 0xFF
                val sG = (sPixel shr 8) and 0xFF
                val sB = sPixel and 0xFF

                val tR = (tPixel shr 16) and 0xFF
                val tG = (tPixel shr 8) and 0xFF
                val tB = tPixel and 0xFF

                val diff = kotlin.math.sqrt(
                    ((sR - tR) * (sR - tR) +
                     (sG - tG) * (sG - tG) +
                     (sB - tB) * (sB - tB)).toDouble()
                )
                sumDiff += diff
            }
        }

        val avgDiff = sumDiff / totalPixels
        return 1.0 - (avgDiff / 441.67)
    }

    suspend fun findImageInScreen(
        templatePath: String,
        similarity: Double = 0.9
    ): Rect? = withContext(Dispatchers.Default) {
        val templateFile = File(templatePath)
        if (!templateFile.exists()) return@withContext null

        val templateBitmap = BitmapFactory.decodeFile(templatePath) ?: return@withContext null
        
        val screenBitmap = captureScreen() ?: return@withContext null

        findImage(screenBitmap, templateBitmap, similarity)
    }

    suspend fun findAllImages(
        sourceBitmap: Bitmap,
        templateBitmap: Bitmap,
        similarity: Double = 0.9
    ): List<Rect> = withContext(Dispatchers.Default) {
        val results = mutableListOf<Rect>()
        
        val sourceWidth = sourceBitmap.width
        val sourceHeight = sourceBitmap.height
        val templateWidth = templateBitmap.width
        val templateHeight = templateBitmap.height

        if (templateWidth > sourceWidth || templateHeight > sourceHeight) {
            return@withContext emptyList()
        }

        val sourcePixels = IntArray(sourceWidth * sourceHeight)
        val templatePixels = IntArray(templateWidth * templateHeight)
        sourceBitmap.getPixels(sourcePixels, 0, sourceWidth, 0, 0, sourceWidth, sourceHeight)
        templateBitmap.getPixels(templatePixels, 0, templateWidth, 0, 0, templateWidth, templateHeight)

        val stepX = templateWidth
        val stepY = templateHeight

        for (y in 0..(sourceHeight - templateHeight) step stepY) {
            for (x in 0..(sourceWidth - templateWidth) step stepX) {
                val score = calculateSimilarity(
                    sourcePixels, sourceWidth, x, y,
                    templatePixels, templateWidth, templateHeight
                )
                if (score >= similarity) {
                    results.add(Rect(x, y, x + templateWidth, y + templateHeight))
                }
            }
        }

        results
    }

    fun findColor(
        bitmap: Bitmap,
        targetColor: Int,
        tolerance: Int = 10
    ): Rect? {
        val width = bitmap.width
        val height = bitmap.height

        for (x in 0 until width) {
            for (y in 0 until height) {
                val pixel = bitmap.getPixel(x, y)
                if (colorMatch(pixel, targetColor, tolerance)) {
                    return Rect(x, y, x + 1, y + 1)
                }
            }
        }

        return null
    }

    fun findAllColors(
        bitmap: Bitmap,
        targetColor: Int,
        tolerance: Int = 10
    ): List<Rect> {
        val results = mutableListOf<Rect>()
        val width = bitmap.width
        val height = bitmap.height

        for (x in 0 until width) {
            for (y in 0 until height) {
                val pixel = bitmap.getPixel(x, y)
                if (colorMatch(pixel, targetColor, tolerance)) {
                    results.add(Rect(x, y, x + 1, y + 1))
                }
            }
        }

        return results
    }

    private fun colorMatch(color1: Int, color2: Int, tolerance: Int): Boolean {
        val r1 = (color1 shr 16) and 0xFF
        val g1 = (color1 shr 8) and 0xFF
        val b1 = color1 and 0xFF

        val r2 = (color2 shr 16) and 0xFF
        val g2 = (color2 shr 8) and 0xFF
        val b2 = color2 and 0xFF

        return kotlin.math.abs(r1 - r2) <= tolerance &&
               kotlin.math.abs(g1 - g2) <= tolerance &&
               kotlin.math.abs(b1 - b2) <= tolerance
    }

    private fun captureScreen(): Bitmap? {
        val service = AccessibilityServiceImpl.getInstance() ?: return null
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        }
        
        return null
    }

    fun compareImages(bitmap1: Bitmap, bitmap2: Bitmap): Double {
        if (bitmap1.width != bitmap2.width || bitmap1.height != bitmap2.height) {
            return 0.0
        }

        val width = bitmap1.width
        val height = bitmap1.height
        val pixels1 = IntArray(width * height)
        val pixels2 = IntArray(width * height)
        bitmap1.getPixels(pixels1, 0, width, 0, 0, width, height)
        bitmap2.getPixels(pixels2, 0, width, 0, 0, width, height)

        var matchingPixels = 0
        for (i in pixels1.indices) {
            if (colorMatch(pixels1[i], pixels2[i], 10)) {
                matchingPixels++
            }
        }

        return matchingPixels.toDouble() / pixels1.size
    }
}
