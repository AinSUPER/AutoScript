package com.autoscript.recognizer.image

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import com.autoscript.model.recognizer.MatchResult

class TemplateMatcher {
    
    private var isInitialized = true
    
    fun initialize(): Boolean {
        return true
    }
    
    fun release() {
        isInitialized = false
    }
    
    fun match(
        source: Bitmap,
        template: Bitmap,
        confidence: Float = 0.8f,
        region: Rect? = null
    ): MatchResult {
        if (!isInitialized) {
            return MatchResult.Builder()
                .matched(false)
                .confidence(0f)
                .matchType(MatchResult.MatchType.TEMPLATE)
                .build()
        }
        
        val searchLeft = region?.left ?: 0
        val searchTop = region?.top ?: 0
        val searchRight = region?.right ?: source.width
        val searchBottom = region?.bottom ?: source.height
        
        val searchWidth = searchRight - searchLeft
        val searchHeight = searchBottom - searchTop
        
        if (template.width > searchWidth || template.height > searchHeight) {
            return MatchResult.Builder()
                .matched(false)
                .confidence(0f)
                .matchType(MatchResult.MatchType.TEMPLATE)
                .build()
        }
        
        val result = findBestMatch(source, template, searchLeft, searchTop, searchRight, searchBottom)
        
        return if (result.confidence >= confidence) {
            result
        } else {
            MatchResult.Builder()
                .matched(false)
                .confidence(result.confidence)
                .matchType(MatchResult.MatchType.TEMPLATE)
                .build()
        }
    }
    
    fun matchMultiScale(
        source: Bitmap,
        template: Bitmap,
        confidence: Float = 0.8f,
        scales: FloatArray = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f),
        region: Rect? = null
    ): MatchResult {
        var bestResult: MatchResult? = null
        
        for (scale in scales) {
            val scaledTemplate = scaleBitmap(template, scale)
            val result = match(source, scaledTemplate, confidence, region)
            
            if (result.matched) {
                if (bestResult == null || result.confidence > bestResult.confidence) {
                    bestResult = result.copy(scale = scale)
                }
            }
            
            if (scaledTemplate != template) {
                scaledTemplate.recycle()
            }
        }
        
        return bestResult ?: MatchResult.Builder()
            .matched(false)
            .confidence(0f)
            .matchType(MatchResult.MatchType.TEMPLATE)
            .build()
    }
    
    fun matchWithRotation(
        source: Bitmap,
        template: Bitmap,
        confidence: Float = 0.8f,
        angles: FloatArray = floatArrayOf(0f, 90f, 180f, 270f),
        region: Rect? = null
    ): MatchResult {
        var bestResult: MatchResult? = null
        
        for (angle in angles) {
            val rotatedTemplate = rotateBitmap(template, angle)
            val result = match(source, rotatedTemplate, confidence, region)
            
            if (result.matched) {
                if (bestResult == null || result.confidence > bestResult.confidence) {
                    bestResult = result.copy(rotation = angle)
                }
            }
            
            if (rotatedTemplate != template) {
                rotatedTemplate.recycle()
            }
        }
        
        return bestResult ?: MatchResult.Builder()
            .matched(false)
            .confidence(0f)
            .matchType(MatchResult.MatchType.TEMPLATE)
            .build()
    }
    
    fun matchAll(
        source: Bitmap,
        template: Bitmap,
        confidence: Float = 0.8f,
        maxResults: Int = 10,
        region: Rect? = null
    ): List<MatchResult> {
        val results = mutableListOf<MatchResult>()
        
        val searchLeft = region?.left ?: 0
        val searchTop = region?.top ?: 0
        val searchRight = region?.right ?: source.width
        val searchBottom = region?.bottom ?: source.height
        
        val sourcePixels = IntArray(source.width * source.height)
        val templatePixels = IntArray(template.width * template.height)
        source.getPixels(sourcePixels, 0, source.width, 0, 0, source.width, source.height)
        template.getPixels(templatePixels, 0, template.width, 0, 0, template.width, template.height)
        
        val templateWidth = template.width
        val templateHeight = template.height
        val sourceWidth = source.width
        
        val stepX = templateWidth
        val stepY = templateHeight
        
        for (y in searchTop..(searchBottom - templateHeight) step stepY) {
            for (x in searchLeft..(searchRight - templateWidth) step stepX) {
                val score = calculateSimilarity(
                    sourcePixels, sourceWidth, x, y,
                    templatePixels, templateWidth, templateHeight
                )
                
                if (score >= confidence) {
                    val matchResult = MatchResult.Builder()
                        .matched(true)
                        .confidence(score)
                        .bounds(Rect(x, y, x + templateWidth, y + templateHeight))
                        .matchType(MatchResult.MatchType.TEMPLATE)
                        .build()
                    
                    results.add(matchResult)
                    
                    if (results.size >= maxResults) {
                        return results
                    }
                }
            }
        }
        
        return results
    }
    
    private fun findBestMatch(
        source: Bitmap,
        template: Bitmap,
        searchLeft: Int,
        searchTop: Int,
        searchRight: Int,
        searchBottom: Int
    ): MatchResult {
        val sourcePixels = IntArray(source.width * source.height)
        val templatePixels = IntArray(template.width * template.height)
        source.getPixels(sourcePixels, 0, source.width, 0, 0, source.width, source.height)
        template.getPixels(templatePixels, 0, template.width, 0, 0, template.width, template.height)
        
        val templateWidth = template.width
        val templateHeight = template.height
        val sourceWidth = source.width
        
        var bestScore = 0f
        var bestX = 0
        var bestY = 0
        
        val stepX = (templateWidth / 4).coerceAtLeast(1)
        val stepY = (templateHeight / 4).coerceAtLeast(1)
        
        for (y in searchTop..(searchBottom - templateHeight) step stepY) {
            for (x in searchLeft..(searchRight - templateWidth) step stepX) {
                val score = calculateSimilarity(
                    sourcePixels, sourceWidth, x, y,
                    templatePixels, templateWidth, templateHeight
                )
                
                if (score > bestScore) {
                    bestScore = score
                    bestX = x
                    bestY = y
                }
            }
        }
        
        return MatchResult.Builder()
            .matched(bestScore >= 0.5f)
            .confidence(bestScore)
            .bounds(Rect(bestX, bestY, bestX + templateWidth, bestY + templateHeight))
            .matchType(MatchResult.MatchType.TEMPLATE)
            .build()
    }
    
    private fun calculateSimilarity(
        source: IntArray, sourceWidth: Int, startX: Int, startY: Int,
        template: IntArray, templateWidth: Int, templateHeight: Int
    ): Float {
        var sumDiff = 0.0
        val totalPixels = templateWidth * templateHeight
        
        for (ty in 0 until templateHeight) {
            for (tx in 0 until templateWidth) {
                val sourceIdx = (startY + ty) * sourceWidth + (startX + tx)
                val templateIdx = ty * templateWidth + tx
                
                val sPixel = source[sourceIdx]
                val tPixel = template[templateIdx]
                
                val sR = (sPixel shr 16) and 0xFF
                val sG = (sPixel shr 8) and 0xFF
                val sB = sPixel and 0xFF
                
                val tR = (tPixel shr 16) and 0xFF
                val tG = (tPixel shr 8) and 0xFF
                val tB = tPixel and 0xFF
                
                val diff = kotlin.math.sqrt(
                    ((sR - tR) * (sR - tR) +
                     (sG - tG) * (sG - tG) +
                     (sB - tB) * (sB - tB)).toDouble()
                )
                sumDiff += diff
            }
        }
        
        val avgDiff = sumDiff / totalPixels
        return (1.0 - (avgDiff / 441.67)).toFloat()
    }
    
    private fun scaleBitmap(bitmap: Bitmap, scale: Float): Bitmap {
        if (scale == 1.0f) return bitmap
        
        val width = (bitmap.width * scale).toInt()
        val height = (bitmap.height * scale).toInt()
        
        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }
    
    private fun rotateBitmap(bitmap: Bitmap, angle: Float): Bitmap {
        if (angle == 0f) return bitmap
        
        val matrix = Matrix()
        matrix.postRotate(angle)
        
        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            matrix,
            true
        )
    }
    
    fun calculateSimilarity(bitmap1: Bitmap, bitmap2: Bitmap): Float {
        if (bitmap1.width != bitmap2.width || bitmap1.height != bitmap2.height) {
            return 0f
        }
        
        val pixels1 = IntArray(bitmap1.width * bitmap1.height)
        val pixels2 = IntArray(bitmap2.width * bitmap2.height)
        bitmap1.getPixels(pixels1, 0, bitmap1.width, 0, 0, bitmap1.width, bitmap1.height)
        bitmap2.getPixels(pixels2, 0, bitmap2.width, 0, 0, bitmap2.width, bitmap2.height)
        
        var matchingPixels = 0
        for (i in pixels1.indices) {
            val p1 = pixels1[i]
            val p2 = pixels2[i]
            
            val r1 = (p1 shr 16) and 0xFF
            val g1 = (p1 shr 8) and 0xFF
            val b1 = p1 and 0xFF
            
            val r2 = (p2 shr 16) and 0xFF
            val g2 = (p2 shr 8) and 0xFF
            val b2 = p2 and 0xFF
            
            if (kotlin.math.abs(r1 - r2) <= 10 &&
                kotlin.math.abs(g1 - g2) <= 10 &&
                kotlin.math.abs(b1 - b2) <= 10) {
                matchingPixels++
            }
        }
        
        return matchingPixels.toFloat() / pixels1.size
    }
}
