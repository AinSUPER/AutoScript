package com.autoscript.recognizer.image

import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import com.autoscript.model.recognizer.MatchResult

class FeatureMatcher {
    
    private var isInitialized = true
    
    fun initialize(): Boolean {
        return true
    }
    
    fun release() {
        isInitialized = false
    }
    
    enum class FeatureMethod {
        PIXEL,
        CORNER,
        EDGE
    }
    
    fun match(
        source: Bitmap,
        template: Bitmap,
        confidence: Float = 0.7f
    ): MatchResult {
        return matchWithMethod(source, template, FeatureMethod.PIXEL, confidence)
    }
    
    fun matchWithMethod(
        source: Bitmap,
        template: Bitmap,
        method: FeatureMethod,
        confidence: Float = 0.7f
    ): MatchResult {
        if (!isInitialized) {
            return MatchResult.Builder()
                .matched(false)
                .confidence(0f)
                .matchType(MatchResult.MatchType.FEATURE)
                .build()
        }
        
        if (template.width > source.width || template.height > source.height) {
            return MatchResult.Builder()
                .matched(false)
                .confidence(0f)
                .matchType(MatchResult.MatchType.FEATURE)
                .build()
        }
        
        val result = findBestMatchLocation(source, template, confidence)
        
        return result
    }
    
    private fun findBestMatchLocation(
        source: Bitmap,
        template: Bitmap,
        confidence: Float
    ): MatchResult {
        val sourcePixels = IntArray(source.width * source.height)
        val templatePixels = IntArray(template.width * template.height)
        source.getPixels(sourcePixels, 0, source.width, 0, 0, source.width, source.height)
        template.getPixels(templatePixels, 0, template.width, 0, 0, template.width, template.height)
        
        val templateWidth = template.width
        val templateHeight = template.height
        val sourceWidth = source.width
        
        var bestScore = 0f
        var bestX = 0
        var bestY = 0
        
        val stepX = (templateWidth / 3).coerceAtLeast(1)
        val stepY = (templateHeight / 3).coerceAtLeast(1)
        
        for (y in 0..(source.height - templateHeight) step stepY) {
            for (x in 0..(source.width - templateWidth) step stepX) {
                val score = calculateFeatureScore(
                    sourcePixels, sourceWidth, x, y,
                    templatePixels, templateWidth, templateHeight
                )
                
                if (score > bestScore) {
                    bestScore = score
                    bestX = x
                    bestY = y
                }
            }
        }
        
        return MatchResult.Builder()
            .matched(bestScore >= confidence)
            .confidence(bestScore)
            .bounds(Rect(bestX, bestY, bestX + templateWidth, bestY + templateHeight))
            .matchType(MatchResult.MatchType.FEATURE)
            .build()
    }
    
    private fun calculateFeatureScore(
        source: IntArray, sourceWidth: Int, startX: Int, startY: Int,
        template: IntArray, templateWidth: Int, templateHeight: Int
    ): Float {
        var cornerMatches = 0
        var edgeMatches = 0
        var totalCorners = 0
        var totalEdges = 0
        
        for (ty in 0 until templateHeight step 4) {
            for (tx in 0 until templateWidth step 4) {
                val sourceIdx = (startY + ty) * sourceWidth + (startX + tx)
                val templateIdx = ty * templateWidth + tx
                
                val sPixel = source[sourceIdx]
                val tPixel = template[templateIdx]
                
                val sBrightness = getBrightness(sPixel)
                val tBrightness = getBrightness(tPixel)
                
                val isCorner = isCorner(template, templateWidth, templateHeight, tx, ty)
                val isEdge = isEdge(template, templateWidth, templateHeight, tx, ty)
                
                if (isCorner) {
                    totalCorners++
                    if (kotlin.math.abs(sBrightness - tBrightness) < 30) {
                        cornerMatches++
                    }
                }
                
                if (isEdge) {
                    totalEdges++
                    if (kotlin.math.abs(sBrightness - tBrightness) < 40) {
                        edgeMatches++
                    }
                }
            }
        }
        
        val cornerScore = if (totalCorners > 0) cornerMatches.toFloat() / totalCorners else 0f
        val edgeScore = if (totalEdges > 0) edgeMatches.toFloat() / totalEdges else 0f
        
        return (cornerScore * 0.6f + edgeScore * 0.4f)
    }
    
    private fun getBrightness(pixel: Int): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return (r + g + b) / 3
    }
    
    private fun isCorner(pixels: IntArray, width: Int, height: Int, x: Int, y: Int): Boolean {
        if (x < 2 || x >= width - 2 || y < 2 || y >= height - 2) return false
        
        val center = getBrightness(pixels[y * width + x])
        val neighbors = listOf(
            getBrightness(pixels[(y - 2) * width + x]),
            getBrightness(pixels[(y + 2) * width + x]),
            getBrightness(pixels[y * width + (x - 2)]),
            getBrightness(pixels[y * width + (x + 2)])
        )
        
        var diffCount = 0
        for (n in neighbors) {
            if (kotlin.math.abs(center - n) > 50) diffCount++
        }
        
        return diffCount >= 3
    }
    
    private fun isEdge(pixels: IntArray, width: Int, height: Int, x: Int, y: Int): Boolean {
        if (x < 1 || x >= width - 1 || y < 1 || y >= height - 1) return false
        
        val center = getBrightness(pixels[y * width + x])
        val left = getBrightness(pixels[y * width + (x - 1)])
        val right = getBrightness(pixels[y * width + (x + 1)])
        val top = getBrightness(pixels[(y - 1) * width + x])
        val bottom = getBrightness(pixels[(y + 1) * width + x])
        
        val hDiff = kotlin.math.abs(left - right)
        val vDiff = kotlin.math.abs(top - bottom)
        
        return hDiff > 40 || vDiff > 40
    }
    
    fun matchKNN(
        source: Bitmap,
        template: Bitmap,
        method: FeatureMethod = FeatureMethod.PIXEL,
        confidence: Float = 0.7f,
        ratioThreshold: Float = 0.75f
    ): MatchResult {
        return matchWithMethod(source, template, method, confidence)
    }
    
    fun getKeypointCount(bitmap: Bitmap, method: FeatureMethod = FeatureMethod.PIXEL): Int {
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        
        var count = 0
        for (y in 2 until bitmap.height - 2) {
            for (x in 2 until bitmap.width - 2) {
                if (isCorner(pixels, bitmap.width, bitmap.height, x, y)) {
                    count++
                }
            }
        }
        
        return count
    }
}
